package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import generics.BasePage;

public class contact_page extends BasePage {

	@FindBy(xpath = "//p[text()='Your message has been successfully sent to our team.']")
	private WebElement successMessage;
	
	@FindBy(id = "id_contact")
	private WebElement subjectHeading;
	
	public contact_page(WebDriver driver) {
		super(driver);
	}
	
	public contact_page sendEmail(String email, String order, String message) {
		Select select = new Select(subjectHeading);
		select.selectByVisibleText("Customer service");
		return new contact_page(driver);
	}
	
	public boolean isMessageDisplayed() {
		return waitForElement(successMessage).isDisplayed();
	}

}
